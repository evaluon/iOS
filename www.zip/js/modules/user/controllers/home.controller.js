(function(){
    'use strict';

    angular
        .module('evaluon.user')
        .controller('HomeController', HomeController);

    function HomeController(){

    };
})();
